dllutl.rb: dynamic import source generator for dll (vorbis, gogo).
lspatch.pl: List the entire instrument configuration

